Macro {
  area="Shell"; key="Alt"; description="Use Alt to activate menu"; action = function()
Keys('F9')
  end;
}

Macro {
  area="MainMenu"; key="Alt"; description="Use Alt to deactivate menu"; action = function()
Keys('Esc')
  end;
}
