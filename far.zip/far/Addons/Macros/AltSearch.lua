Macro {
  area="Shell"; key="Alt"; description="Use Alt for search by name (activate)"; action = function()
Keys('Alt<')
  end;
}

Macro {
  area="Search"; key="Alt"; description="Use Alt for search by name (deactivate)"; action = function()
Keys('Esc')
  end;
}
