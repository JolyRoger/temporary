Macro {
  area="Editor"; key="CtrlDel CtrlNumDel"; flags="EVSelection"; description="Ctrl-Del removes selected editor block"; action = function()
Keys('CtrlD')
  end;
}
