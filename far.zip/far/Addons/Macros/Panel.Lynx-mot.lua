Macro {
  area="Shell"; key="Left"; flags="EmptyCommandLine"; description="LYNX-style motion"; action = function()
Keys('CtrlPgUp')
  end;
}

Macro {
  area="Shell"; key="Right"; flags="EmptyCommandLine"; description="LYNX-style motion"; action = function()
Keys('CtrlPgDn')
  end;
}

